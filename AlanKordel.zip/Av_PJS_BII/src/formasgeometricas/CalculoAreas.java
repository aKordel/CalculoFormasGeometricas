package formasgeometricas;

public interface CalculoAreas { //INTERFACE calculo de areas das figuras
	
	 double calcularArea(); //metodo abstrato

}
