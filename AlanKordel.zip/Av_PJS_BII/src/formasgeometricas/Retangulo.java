package formasgeometricas;

public class Retangulo extends Forma { //Classe retangulo que herda de Forma
	
	double base;
	double altura;
	

	public Retangulo(int id, String corLinha, String corPreenchimento, double base, double altura) {
		super(id, corLinha, corPreenchimento);
		this.base = base;
		this.altura = altura;
		
	}



	public double getBase() {
		return base;
	}



	public void setBase(double base) {
		this.base = base;
	}



	public double getAltura() {
		return altura;
	}



	public void setAltura(double altura) {
		this.altura = altura;
	}



	@Override
	public double calcularArea() { // INTERFACE CalculoAreas, onde � usado o metodo  abstrato calcularArea
		// TODO Auto-generated method stub
		this.area = (base*altura);
		return area;
	}



	@Override
	public String toString() {
		return "\nRetangulo ID: " + id + "\nCor da linha: " +  corLinha + "\nCor do preenchimento: " + corPreenchimento +
				"\nLargura digitado: "+base + "\n Altura digitado: "+ altura + "\nArea:" + area + "\n";
	}
	
	

}
