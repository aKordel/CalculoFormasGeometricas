package formasgeometricas;

public abstract class Forma implements CalculoAreas, Comparable<Forma> { //Classe abstrata de forma, onde implementa as interfaces
	//CalculoArea e Comparable -- Classe Pai
	
	int id = 0;
	String corLinha;
	String corPreenchimento;
	double area;
	
	
	public double getArea() {
		return area;
	}


	public void setArea(double area) {
		this.area = area;
	}


	public Forma(int id, String corLinha, String corPreenchimento) {
		super();
		this.id = id;
		this.corLinha = corLinha;
		this.corPreenchimento = corPreenchimento;
		
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id++;
	}
	public String getCorLinha() {
		return corLinha;
	}
	public void setCorLinha(String corLinha) {
		this.corLinha = corLinha;
	}
	public String getCorPreenchimento() {
		return corPreenchimento;
	}
	public void setCorPreenchimento(String corPreenchimento) {
		this.corPreenchimento = corPreenchimento;
	}
	public double calcularArea() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override public int compareTo(Forma outraForma) { //implementa��o do metodo compareTo da interface Comparable
		if (this.area > outraForma.getArea()) {  //Logica pra ver qual area � a maior, e organizar em ordem do Maior para menor
			
			  return -1; 
			  } if (this.area < outraForma.getArea()) { 
			  return 1; 
			  } 
			  return 0;

	}
	/*  Para alocar a forma mais a esquerda da lista, retornamos -1.
		Para alocar a forma mais a direita da lista, retornamos 1.
		quando retornamos 0 significa que as formas comparadas s�o iguais e n�o alteram suas posi��es.
	*/
	
}
