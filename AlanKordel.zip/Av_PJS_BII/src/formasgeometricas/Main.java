package formasgeometricas;

import java.util.ArrayList;
import java.util.*;

public class Main {
	
	public static void main(String[] args) {
		
		
		ArrayList<Circulo> listaCirculos = new ArrayList<Circulo>(); //Lista Circulos
		ArrayList<Triangulo> listaTriangulos = new ArrayList<Triangulo>();//Lista Triangulos
		ArrayList<Retangulo> listaRetangulos = new ArrayList<Retangulo>();//Lista Retangulos
		
		ArrayList<Forma> listaFiguras = new ArrayList<Forma>(); //Lista de formas
		
		
		
		
		int op;
		String corLinha, corPreenchimento;
		double base,altura,largura;
		int contID = 0;
		
		Scanner sc = new Scanner(System.in);		
		System.out.println("#FORMAS GEOMETRICAS#\n");
		
		
	do {
		
		 MenuInicial();
		
		 op = sc.nextInt();
		 
		
		switch(op){
		
		case 1:
			
			System.out.println("----INSIRA OS VALORES PARA CALCULAR O RETANGULO----\n\n");
			contID++;
			
			System.out.println("Insira o valor da base: ");
			base = sc.nextInt();
			System.out.println("Insira o valor da altura: ");
			altura= sc.nextInt();
			System.out.println("Insira a cor da linha da figura: ");
			corLinha = sc.next();
			System.out.println("Insira o valor do Prenchimento: ");
			corPreenchimento = sc.next();
			
			
			Retangulo retangulo = new Retangulo (contID, corLinha, corPreenchimento, base,altura); //instanciando objeto
			retangulo.calcularArea(); //calculando a area
			listaRetangulos.add(retangulo);	//adicionando a lista de retangulos
			listaFiguras.add(retangulo);//adicionando a lista de figuras
			Continua();
			
			
			break;
			
		case 2:
			System.out.println("----INSIRA OS VALORES PARA CALCULAR O TRIANGULO----\n\n");
			contID++;
			
			System.out.println("Insira o valor da base: ");
			largura = sc.nextInt();
			System.out.println("Insira o valor da altura: ");
			altura= sc.nextInt();
			System.out.println("Insira a cor da linha da figura: ");
			corLinha = sc.next();
			System.out.println("Insira o valor do Prenchimento: ");
			corPreenchimento = sc.next();
			
			Triangulo triangulo = new Triangulo(contID, corLinha, corPreenchimento, largura,altura);
			triangulo.calcularArea();
			listaTriangulos.add(triangulo);
			listaFiguras.add(triangulo);		
			Continua();		
			
			break;
		case 3:
			contID++;
			System.out.println("----INSIRA OS VALORES PARA CALCULAR O CIRCULO----\n\n");
			int raio;
			
			System.out.println("Insira o valor do raio: ");
			raio = sc.nextInt();
			System.out.println("Insira a cor da linha do circulo: ");
			corLinha = sc.next();
			System.out.println("Insira o valor do Prenchimento: ");
			corPreenchimento = sc.next();
			
			
			Circulo circulo = new Circulo(contID, corLinha, corPreenchimento, raio);
			circulo.calcularArea();
			listaFiguras.add(circulo);
			
			listaCirculos.add(circulo);		
			Continua();
					
			
			break;
		case 4:
			System.out.println("----LISTA DE RETANGULOS----\n\n");
			System.out.print(listaRetangulos);
			Continua();
			
			
			break;
		case 5:
			System.out.println("----LISTA DE TRIANGULOS----\n\n");
			System.out.print(listaTriangulos);
			Continua();
			
			break;
		case 6:
			System.out.println("----LISTA DE CIRCULOS----\n\n");
			System.out.print("\n"+listaCirculos);
			Continua();
			
			break;
		case 7:
			System.out.println("---LISTA DE FIGURAS ORDENADAS DE FORMA CRESCENTE PELA AREA--\n\n ");
			Collections.sort(listaFiguras); //Ordenando a listaFiguras da maior AREA para menor AREA
			System.out.print(listaFiguras);
			Continua();
			
			
			break;

		case 8:
			System.out.println("Voc� saiu do programa\r\n");
			
			break;
			
			
			
		default: System.out.println("Op��o Invalidada:");
			
		}

		

		
	}while(op!=10);
		
		
		
	}
	
	
	private static void MenuInicial() {
		
		
		System.out.println("1. Inserir retangulo\r\n"
				+ "2. Inserir triangulo\r\n"
				+ "3. Inserir Circulo\r\n"
				+ "4. Listar retangulos\r\n"
				+ "5. Listar triangulos\r\n"
				+ "6. Listar circulos\r\n"
				+ "7. Listar todas as formas ordenadas pela �rea\r\n"
				+ "8. Sair\r\n"
				+ "\nDigite sua op��o: ");	
		}
    public static void Continua()
    {
    	Scanner sc = new Scanner(System.in);
        System.out.println("\n\nAperte enter para continuar...\n");
        sc.nextLine();
    }

}
